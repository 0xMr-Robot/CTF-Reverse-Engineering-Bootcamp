﻿#include <stdio.h>
#include <stdint.h>
#include <string.h>

// Simple DES (Data Encryption Standard) Implementation
// DES is a symmetric block cipher that was the standard from 1977 to early 2000s

#define BLOCK_SIZE 8  // 64-bit block size (8 bytes)
#define KEY_SIZE 8    // 64-bit key (56 bits + 8 parity bits)

/*
DES ENCRYPTION EXPLAINED:
DES works on 64-bit blocks (8 bytes) using a 56-bit key.
It uses a Feistel network structure with 16 rounds.

Main Steps:
1. Initial Permutation (IP) - Rearrange bits
2. 16 Rounds of Feistel Function
3. Final Permutation (IP⁻¹) - Reverse of initial permutation

Feistel Round Structure:
- Split 64-bit block into two 32-bit halves (L and R)
- R becomes new L
- New R = L XOR Feistel(R, subkey)
*/

// Initial Permutation Table
const int IP[64] = {
    58, 50, 42, 34, 26, 18, 10, 2,
    60, 52, 44, 36, 28, 20, 12, 4,
    62, 54, 46, 38, 30, 22, 14, 6,
    64, 56, 48, 40, 32, 24, 16, 8,
    57, 49, 41, 33, 25, 17, 9, 1,
    59, 51, 43, 35, 27, 19, 11, 3,
    61, 53, 45, 37, 29, 21, 13, 5,
    63, 55, 47, 39, 31, 23, 15, 7
};

// Final Permutation Table (Inverse of Initial Permutation)
const int FP[64] = {
    40, 8, 48, 16, 56, 24, 64, 32,
    39, 7, 47, 15, 55, 23, 63, 31,
    38, 6, 46, 14, 54, 22, 62, 30,
    37, 5, 45, 13, 53, 21, 61, 29,
    36, 4, 44, 12, 52, 20, 60, 28,
    35, 3, 43, 11, 51, 19, 59, 27,
    34, 2, 42, 10, 50, 18, 58, 26,
    33, 1, 41, 9, 49, 17, 57, 25
};

// Expansion Permutation (32 bits -> 48 bits)
const int EXPANSION[48] = {
    32, 1, 2, 3, 4, 5,
    4, 5, 6, 7, 8, 9,
    8, 9, 10, 11, 12, 13,
    12, 13, 14, 15, 16, 17,
    16, 17, 18, 19, 20, 21,
    20, 21, 22, 23, 24, 25,
    24, 25, 26, 27, 28, 29,
    28, 29, 30, 31, 32, 1
};

// S-Boxes (8 boxes, each 4x16)
const uint8_t S_BOX[8][4][16] = {
    // S1
    {
        {14, 4, 13, 1, 2, 15, 11, 8, 3, 10, 6, 12, 5, 9, 0, 7},
        {0, 15, 7, 4, 14, 2, 13, 1, 10, 6, 12, 11, 9, 5, 3, 8},
        {4, 1, 14, 8, 13, 6, 2, 11, 15, 12, 9, 7, 3, 10, 5, 0},
        {15, 12, 8, 2, 4, 9, 1, 7, 5, 11, 3, 14, 10, 0, 6, 13}
    },
    // S2
    {
        {15, 1, 8, 14, 6, 11, 3, 4, 9, 7, 2, 13, 12, 0, 5, 10},
        {3, 13, 4, 7, 15, 2, 8, 14, 12, 0, 1, 10, 6, 9, 11, 5},
        {0, 14, 7, 11, 10, 4, 13, 1, 5, 8, 12, 6, 9, 3, 2, 15},
        {13, 8, 10, 1, 3, 15, 4, 2, 11, 6, 7, 12, 0, 5, 14, 9}
    },
    // S3
    {
        {10, 0, 9, 14, 6, 3, 15, 5, 1, 13, 12, 7, 11, 4, 2, 8},
        {13, 7, 0, 9, 3, 4, 6, 10, 2, 8, 5, 14, 12, 11, 15, 1},
        {13, 6, 4, 9, 8, 15, 3, 0, 11, 1, 2, 12, 5, 10, 14, 7},
        {1, 10, 13, 0, 6, 9, 8, 7, 4, 15, 14, 3, 11, 5, 2, 12}
    },
    // S4
    {
        {7, 13, 14, 3, 0, 6, 9, 10, 1, 2, 8, 5, 11, 12, 4, 15},
        {13, 8, 11, 5, 6, 15, 0, 3, 4, 7, 2, 12, 1, 10, 14, 9},
        {10, 6, 9, 0, 12, 11, 7, 13, 15, 1, 3, 14, 5, 2, 8, 4},
        {3, 15, 0, 6, 10, 1, 13, 8, 9, 4, 5, 11, 12, 7, 2, 14}
    },
    // S5
    {
        {2, 12, 4, 1, 7, 10, 11, 6, 8, 5, 3, 15, 13, 0, 14, 9},
        {14, 11, 2, 12, 4, 7, 13, 1, 5, 0, 15, 10, 3, 9, 8, 6},
        {4, 2, 1, 11, 10, 13, 7, 8, 15, 9, 12, 5, 6, 3, 0, 14},
        {11, 8, 12, 7, 1, 14, 2, 13, 6, 15, 0, 9, 10, 4, 5, 3}
    },
    // S6
    {
        {12, 1, 10, 15, 9, 2, 6, 8, 0, 13, 3, 4, 14, 7, 5, 11},
        {10, 15, 4, 2, 7, 12, 9, 5, 6, 1, 13, 14, 0, 11, 3, 8},
        {9, 14, 15, 5, 2, 8, 12, 3, 7, 0, 4, 10, 1, 13, 11, 6},
        {4, 3, 2, 12, 9, 5, 15, 10, 11, 14, 1, 7, 6, 0, 8, 13}
    },
    // S7
    {
        {4, 11, 2, 14, 15, 0, 8, 13, 3, 12, 9, 7, 5, 10, 6, 1},
        {13, 0, 11, 7, 4, 9, 1, 10, 14, 3, 5, 12, 2, 15, 8, 6},
        {1, 4, 11, 13, 12, 3, 7, 14, 10, 15, 6, 8, 0, 5, 9, 2},
        {6, 11, 13, 8, 1, 4, 10, 7, 9, 5, 0, 15, 14, 2, 3, 12}
    },
    // S8
    {
        {13, 2, 8, 4, 6, 15, 11, 1, 10, 9, 3, 14, 5, 0, 12, 7},
        {1, 15, 13, 8, 10, 3, 7, 4, 12, 5, 6, 11, 0, 14, 9, 2},
        {7, 11, 4, 1, 9, 12, 14, 2, 0, 6, 10, 13, 15, 3, 5, 8},
        {2, 1, 14, 7, 4, 10, 8, 13, 15, 12, 9, 0, 3, 5, 6, 11}
    }
};

// Straight Permutation (after S-Boxes)
const int P[32] = {
    16, 7, 20, 21, 29, 12, 28, 17,
    1, 15, 23, 26, 5, 18, 31, 10,
    2, 8, 24, 14, 32, 27, 3, 9,
    19, 13, 30, 6, 22, 11, 4, 25
};

// Helper function to get a specific bit from data
int get_bit(uint64_t data, int position) {
    /*
    GET BIT:
    Extract a specific bit (1-indexed) from 64-bit data.
    Position 1 is the most significant bit.
    */
    return (data >> (64 - position)) & 1;
}

// Helper function to set a specific bit in data
uint64_t set_bit(uint64_t data, int position, int value) {
    /*
    SET BIT:
    Set a specific bit (1-indexed) in 64-bit data.
    */
    if (value) {
        return data | (1ULL << (64 - position));
    }
    else {
        return data & ~(1ULL << (64 - position));
    }
}

// Apply permutation to data
uint64_t permute(uint64_t data, const int* table, int table_size) {
    /*
    PERMUTE:
    Rearrange bits according to permutation table.
    Tables are 1-indexed (bit positions start from 1).
    */
    uint64_t result = 0;

    for (int i = 0; i < table_size; i++) {
        int bit_pos = table[i];
        int bit_value = get_bit(data, bit_pos);
        result = set_bit(result, i + 1, bit_value);
    }

    return result;
}

// Initial Permutation
uint64_t initial_permutation(uint64_t block) {
    /*
    INITIAL PERMUTATION:
    Rearrange the 64 bits of the input block according to IP table.
    This is the first step of DES encryption.
    */
    return permute(block, IP, 64);
}

// Final Permutation
uint64_t final_permutation(uint64_t block) {
    /*
    FINAL PERMUTATION:
    Rearrange the 64 bits according to FP table (inverse of IP).
    This is the last step of DES encryption.
    */
    return permute(block, FP, 64);
}

// Expansion function (32 bits -> 48 bits)
uint64_t expansion(uint32_t right_half) {
    /*
    EXPANSION FUNCTION:
    Expand 32-bit right half to 48 bits using expansion table.
    This provides more bits to mix with the subkey.
    */
    uint64_t expanded = 0;

    for (int i = 0; i < 48; i++) {
        int bit_pos = EXPANSION[i];
        int bit_value = (right_half >> (32 - bit_pos)) & 1;
        expanded = (expanded << 1) | bit_value;
    }

    return expanded;
}

// S-Box substitution (48 bits -> 32 bits)
uint32_t s_box_substitution(uint64_t data) {
    /*
    S-BOX SUBSTITUTION:
    The core non-linear operation of DES.
    - Split 48-bit input into 8 groups of 6 bits
    - Each group goes through a different S-Box
    - Each S-Box converts 6 bits to 4 bits
    - Result: 8 × 4 = 32 bits
    */
    uint32_t result = 0;

    for (int i = 0; i < 8; i++) {
        // Extract 6 bits for this S-Box
        int chunk = (data >> (42 - i * 6)) & 0x3F;

        // Calculate row and column for S-Box lookup
        int row = ((chunk & 0x20) >> 4) | (chunk & 0x01);
        int col = (chunk >> 1) & 0x0F;

        // Get S-Box value and add to result
        uint8_t s_val = S_BOX[i][row][col];
        result = (result << 4) | s_val;
    }

    return result;
}

// Feistel function (the heart of DES)
uint32_t feistel_function(uint32_t right_half, uint64_t subkey) {
    /*
    FEISTEL FUNCTION:
    1. Expand 32-bit right half to 48 bits
    2. XOR with 48-bit subkey
    3. Apply S-Box substitution (48→32 bits)
    4. Apply permutation (32 bits)
    */

    // Step 1: Expansion
    uint64_t expanded = expansion(right_half);

    // Step 2: XOR with subkey
    uint64_t xored = expanded ^ subkey;

    // Step 3: S-Box substitution
    uint32_t substituted = s_box_substitution(xored);

    // Step 4: Permutation
    uint32_t result = 0;
    for (int i = 0; i < 32; i++) {
        int bit_pos = P[i];
        int bit_value = (substituted >> (32 - bit_pos)) & 1;
        result = (result << 1) | bit_value;
    }

    return result;
}

// Simple key schedule (for educational purposes)
uint64_t get_subkey(uint64_t key, int round) {
    /*
    SIMPLE KEY SCHEDULE:
    In real DES, this involves complex bit rotations and permutations.
    For simplicity, we'll just rotate the key differently each round.
    */
    return (key << round) | (key >> (64 - round));
}

// DES Encryption function
uint64_t des_encrypt(uint64_t block, uint64_t key) {
    /*
    DES ENCRYPTION PROCESS:
    1. Apply Initial Permutation
    2. Split into 32-bit left and right halves
    3. 16 rounds of Feistel network
    4. Combine halves and apply Final Permutation
    */

    printf("Starting DES Encryption:\n");

    // Step 1: Initial Permutation
    printf("1. Initial Permutation\n");
    block = initial_permutation(block);

    // Step 2: Split into left and right halves
    uint32_t left = block >> 32;
    uint32_t right = block & 0xFFFFFFFF;

    printf("2. Split into L0 and R0 (32 bits each)\n");

    // Step 3: 16 rounds of Feistel network
    for (int round = 1; round <= 16; round++) {
        printf("   Round %2d: ", round);

        // Get subkey for this round
        uint64_t subkey = get_subkey(key, round);

        // Feistel function
        uint32_t feistel_output = feistel_function(right, subkey);

        // New left is old right
        // New right is old left XOR feistel output
        uint32_t new_left = right;
        uint32_t new_right = left ^ feistel_output;

        left = new_left;
        right = new_right;

        printf("L%d = R%d, R%d = L%d XOR f(R%d, K%d)\n",
            round, round - 1, round, round - 1, round - 1, round);
    }

    // Step 4: Combine halves (swap for final round)
    uint64_t combined = ((uint64_t)right << 32) | left;

    // Step 5: Final Permutation
    printf("3. Final Permutation\n");
    return final_permutation(combined);
}

// Convert 8-byte array to 64-bit integer
uint64_t bytes_to_uint64(const uint8_t* bytes) {
    uint64_t result = 0;
    for (int i = 0; i < 8; i++) {
        result = (result << 8) | bytes[i];
    }
    return result;
}

// Convert 64-bit integer to 8-byte array
void uint64_to_bytes(uint64_t value, uint8_t* bytes) {
    for (int i = 0; i < 8; i++) {
        bytes[i] = (value >> (56 - i * 8)) & 0xFF;
    }
}

// Helper function to print hex data
void print_hex(const char* label, const uint8_t* data, int len) {
    printf("%s: ", label);
    for (int i = 0; i < len; i++) {
        printf("%02X", data[i]);
    }
    printf("\n");
}

int main() {
    printf("=== Simple DES Encryption Demo ===\n\n");

    // Example key (8 bytes = 64 bits)
    uint8_t key[KEY_SIZE] = {
        0x13, 0x34, 0x57, 0x79, 0x9B, 0xBC, 0xDF, 0xF1
    };

    // Example plaintext (8 bytes = 64 bits)
    uint8_t plaintext[BLOCK_SIZE] = {
        0x01, 0x23, 0x45, 0x67, 0x89, 0xAB, 0xCD, 0xEF
    };

    uint8_t ciphertext[BLOCK_SIZE];

    printf("DES Parameters:\n");
    printf("- Block Size: 64 bits (8 bytes)\n");
    printf("- Key Size: 64 bits (8 bytes, 56 bits effective)\n");
    printf("- Rounds: 16\n\n");

    // Show inputs
    print_hex("Key", key, KEY_SIZE);
    print_hex("Plaintext", plaintext, BLOCK_SIZE);
    printf("\n");

    // Convert to 64-bit integers for processing
    uint64_t block = bytes_to_uint64(plaintext);
    uint64_t key64 = bytes_to_uint64(key);

    // Encrypt
    uint64_t encrypted = des_encrypt(block, key64);

    // Convert back to bytes
    uint64_to_bytes(encrypted, ciphertext);

    // Show result
    printf("\n");
    print_hex("Ciphertext", ciphertext, BLOCK_SIZE);

    return 0;
}