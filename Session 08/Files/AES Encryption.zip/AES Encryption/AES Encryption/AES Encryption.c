#include <stdio.h>
#include <stdint.h>
#include <string.h>

// Simple AES-128 Implementation
// This is a simplified version for educational purposes

#define BLOCK_SIZE 16  // 128-bit block size
#define KEY_SIZE 16    // 128-bit key size
#define ROUNDS 10      // 10 rounds for AES-128

// Precomputed S-Box for substitution
const uint8_t s_box[256] = {
    0x63, 0x7C, 0x77, 0x7B, 0xF2, 0x6B, 0x6F, 0xC5, 0x30, 0x01, 0x67, 0x2B, 0xFE, 0xD7, 0xAB, 0x76,
    0xCA, 0x82, 0xC9, 0x7D, 0xFA, 0x59, 0x47, 0xF0, 0xAD, 0xD4, 0xA2, 0xAF, 0x9C, 0xA4, 0x72, 0xC0,
    0xB7, 0xFD, 0x93, 0x26, 0x36, 0x3F, 0xF7, 0xCC, 0x34, 0xA5, 0xE5, 0xF1, 0x71, 0xD8, 0x31, 0x15,
    0x04, 0xC7, 0x23, 0xC3, 0x18, 0x96, 0x05, 0x9A, 0x07, 0x12, 0x80, 0xE2, 0xEB, 0x27, 0xB2, 0x75,
    0x09, 0x83, 0x2C, 0x1A, 0x1B, 0x6E, 0x5A, 0xA0, 0x52, 0x3B, 0xD6, 0xB3, 0x29, 0xE3, 0x2F, 0x84,
    0x53, 0xD1, 0x00, 0xED, 0x20, 0xFC, 0xB1, 0x5B, 0x6A, 0xCB, 0xBE, 0x39, 0x4A, 0x4C, 0x58, 0xCF,
    0xD0, 0xEF, 0xAA, 0xFB, 0x43, 0x4D, 0x33, 0x85, 0x45, 0xF9, 0x02, 0x7F, 0x50, 0x3C, 0x9F, 0xA8,
    0x51, 0xA3, 0x40, 0x8F, 0x92, 0x9D, 0x38, 0xF5, 0xBC, 0xB6, 0xDA, 0x21, 0x10, 0xFF, 0xF3, 0xD2,
    0xCD, 0x0C, 0x13, 0xEC, 0x5F, 0x97, 0x44, 0x17, 0xC4, 0xA7, 0x7E, 0x3D, 0x64, 0x5D, 0x19, 0x73,
    0x60, 0x81, 0x4F, 0xDC, 0x22, 0x2A, 0x90, 0x88, 0x46, 0xEE, 0xB8, 0x14, 0xDE, 0x5E, 0x0B, 0xDB,
    0xE0, 0x32, 0x3A, 0x0A, 0x49, 0x06, 0x24, 0x5C, 0xC2, 0xD3, 0xAC, 0x62, 0x91, 0x95, 0xE4, 0x79,
    0xE7, 0xC8, 0x37, 0x6D, 0x8D, 0xD5, 0x4E, 0xA9, 0x6C, 0x56, 0xF4, 0xEA, 0x65, 0x7A, 0xAE, 0x08,
    0xBA, 0x78, 0x25, 0x2E, 0x1C, 0xA6, 0xB4, 0xC6, 0xE8, 0xDD, 0x74, 0x1F, 0x4B, 0xBD, 0x8B, 0x8A,
    0x70, 0x3E, 0xB5, 0x66, 0x48, 0x03, 0xF6, 0x0E, 0x61, 0x35, 0x57, 0xB9, 0x86, 0xC1, 0x1D, 0x9E,
    0xE1, 0xF8, 0x98, 0x11, 0x69, 0xD9, 0x8E, 0x94, 0x9B, 0x1E, 0x87, 0xE9, 0xCE, 0x55, 0x28, 0xDF,
    0x8C, 0xA1, 0x89, 0x0D, 0xBF, 0xE6, 0x42, 0x68, 0x41, 0x99, 0x2D, 0x0F, 0xB0, 0x54, 0xBB, 0x16
};

// Round constants for key expansion
const uint8_t rcon[10] = { 0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80, 0x1B, 0x36 };

/*
AES ENCRYPTION EXPLAINED:
AES works on 16-byte blocks (128 bits) using a 16-byte key (128 bits).
It has 4 main operations that are repeated for 10 rounds:

1. SubBytes   - Replace each byte using S-Box (provides confusion)
2. ShiftRows  - Shift rows of the state matrix (provides diffusion)
3. MixColumns - Mix data within columns (provides more diffusion)
4. AddRoundKey - XOR with round key (adds key material)

The process:
- Start with AddRoundKey
- Do 9 rounds of all 4 operations
- Final round without MixColumns
*/

// Key Expansion: Generate round keys from main key
void expand_key(const uint8_t* key, uint8_t* round_keys) {
    /*
    KEY EXPANSION:
    We start with the original 16-byte key and generate
    10 additional round keys (160 bytes total).

    Each round key is 16 bytes, and we generate them
    by transforming and combining previous key words.
    */

    // Copy original key as first round key
    memcpy(round_keys, key, 16);

    // Generate remaining round keys
    for (int i = 1; i <= ROUNDS; i++) {
        // Each round key depends on previous round key
        uint8_t* prev_key = round_keys + (i - 1) * 16;
        uint8_t* curr_key = round_keys + i * 16;

        // First word of new key is special
        curr_key[0] = s_box[prev_key[13]] ^ prev_key[0] ^ rcon[i - 1];
        curr_key[1] = s_box[prev_key[14]] ^ prev_key[1];
        curr_key[2] = s_box[prev_key[15]] ^ prev_key[2];
        curr_key[3] = s_box[prev_key[12]] ^ prev_key[3];

        // Remaining words are simpler
        for (int j = 4; j < 16; j++) {
            curr_key[j] = prev_key[j] ^ curr_key[j - 4];
        }
    }
}

// SubBytes: Replace each byte using S-Box
void sub_bytes(uint8_t state[16]) {
    /*
    SUBBYTES OPERATION:
    Each of the 16 bytes in our state is replaced
    with a corresponding byte from the S-Box table.

    This provides non-linearity - makes the encryption
    complex and resistant to mathematical analysis.
    */
    for (int i = 0; i < 16; i++) {
        state[i] = s_box[state[i]];
    }
}

// ShiftRows: Shift rows of the state matrix
void shift_rows(uint8_t state[16]) {
    /*
    SHIFTROWS OPERATION:
    We arrange the 16 bytes as a 4x4 matrix and shift rows:
    - Row 0: no shift
    - Row 1: shift left 1 position
    - Row 2: shift left 2 positions
    - Row 3: shift left 3 positions

    This spreads bytes across different columns.
    */

    // Temporary storage for shifted state
    uint8_t temp[16];

    // Copy with row shifts
    temp[0] = state[0];   temp[1] = state[5];   temp[2] = state[10];  temp[3] = state[15];
    temp[4] = state[4];   temp[5] = state[9];   temp[6] = state[14];  temp[7] = state[3];
    temp[8] = state[8];   temp[9] = state[13];  temp[10] = state[2];   temp[11] = state[7];
    temp[12] = state[12];  temp[13] = state[1];   temp[14] = state[6];   temp[15] = state[11];

    // Copy back to state
    memcpy(state, temp, 16);
}

// MixColumns: Mix data within columns
void mix_columns(uint8_t state[16]) {
    /*
    MIXCOLUMNS OPERATION:
    Each column of the 4x4 state matrix is transformed
    using mathematical operations in a special number system.

    This ensures that changes in one byte affect multiple
    bytes in the next round.
    */

    uint8_t temp[16];

    // Simplified MixColumns for education
    // In real AES, this uses complex Galois Field math
    for (int i = 0; i < 4; i++) {
        int col = i * 4;

        // Each new byte is a combination of all bytes in its column
        temp[col] = (state[col] << 1) ^ (state[col + 1] << 1) ^ state[col + 1] ^ state[col + 2] ^ state[col + 3];
        temp[col + 1] = state[col] ^ (state[col + 1] << 1) ^ (state[col + 2] << 1) ^ state[col + 2] ^ state[col + 3];
        temp[col + 2] = state[col] ^ state[col + 1] ^ (state[col + 2] << 1) ^ (state[col + 3] << 1) ^ state[col + 3];
        temp[col + 3] = (state[col] << 1) ^ state[col] ^ state[col + 1] ^ state[col + 2] ^ (state[col + 3] << 1);
    }

    memcpy(state, temp, 16);
}

// AddRoundKey: XOR state with round key
void add_round_key(uint8_t state[16], const uint8_t* round_key) {
    /*
    ADDROUNDKEY OPERATION:
    Simply XOR each byte of the state with the
    corresponding byte of the round key.

    This is the only step that uses the secret key
    directly, ensuring the encryption depends on it.
    */
    for (int i = 0; i < 16; i++) {
        state[i] ^= round_key[i];
    }
}

// Main AES encryption function
void aes_encrypt(const uint8_t* input, uint8_t* output, const uint8_t* round_keys) {
    /*
    AES ENCRYPTION PROCESS:
    1. Start: Add first round key
    2. Middle: 9 rounds of [SubBytes, ShiftRows, MixColumns, AddRoundKey]
    3. Final: 1 round of [SubBytes, ShiftRows, AddRoundKey] (no MixColumns)
    */

    uint8_t state[16];

    // Copy input to working state
    memcpy(state, input, 16);

    // Initial round - just add round key
    printf("Round 0: AddRoundKey only\n");
    add_round_key(state, round_keys);

    // Main rounds (1-9)
    for (int round = 1; round < ROUNDS; round++) {
        printf("Round %d: ", round);
        printf("SubBytes -> ");
        sub_bytes(state);

        printf("ShiftRows -> ");
        shift_rows(state);

        printf("MixColumns -> ");
        mix_columns(state);

        printf("AddRoundKey\n");
        add_round_key(state, round_keys + round * 16);
    }

    // Final round (10) - no MixColumns
    printf("Round %d: ", ROUNDS);
    printf("SubBytes -> ");
    sub_bytes(state);

    printf("ShiftRows -> ");
    shift_rows(state);

    printf("AddRoundKey (no MixColumns)\n");
    add_round_key(state, round_keys + ROUNDS * 16);

    // Copy final state to output
    memcpy(output, state, 16);
}

// Helper function to print hex data
void print_hex(const char* label, const uint8_t* data, int len) {
    printf("%s: ", label);
    for (int i = 0; i < len; i++) {
        printf("%02X", data[i]);
    }
    printf("\n");
}

int main() {
    printf("=== Simple AES-128 Encryption Demo ===\n\n");

    // Example key (16 bytes = 128 bits)
    uint8_t key[KEY_SIZE] = {
        0x2B, 0x7E, 0x15, 0x16, 0x28, 0xAE, 0xD2, 0xA6,
        0xAB, 0xF7, 0x97, 0x56, 0x19, 0x88, 0x09, 0xCF
    };

    // Example plaintext (16 bytes = 128 bits)
    uint8_t plaintext[BLOCK_SIZE] = {
        0x32, 0x43, 0xF6, 0xA8, 0x88, 0x5A, 0x30, 0x8D,
        0x31, 0x31, 0x98, 0xA2, 0xE0, 0x37, 0x07, 0x34
    };

    uint8_t round_keys[(ROUNDS + 1) * BLOCK_SIZE];  // Storage for all round keys
    uint8_t ciphertext[BLOCK_SIZE];                 // Output ciphertext

    printf("AES Parameters:\n");
    printf("- Block Size: 128 bits (16 bytes)\n");
    printf("- Key Size: 128 bits (16 bytes)\n");
    printf("- Rounds: 10\n\n");

    // Show inputs
    print_hex("Key", key, KEY_SIZE);
    print_hex("Plaintext", plaintext, BLOCK_SIZE);
    printf("\n");

    // Generate round keys
    expand_key(key, round_keys);

    // Encrypt
    printf("Encryption Process:\n");
    aes_encrypt(plaintext, ciphertext, round_keys);
    printf("\n");

    // Show result
    print_hex("Ciphertext", ciphertext, BLOCK_SIZE);

    return 0;
}