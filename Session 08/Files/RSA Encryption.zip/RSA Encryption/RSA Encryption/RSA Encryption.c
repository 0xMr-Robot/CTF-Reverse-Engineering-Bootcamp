﻿#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>

// Simple RSA Encryption Implementation
// RSA is an asymmetric encryption algorithm (public-key cryptography)

/*
RSA ENCRYPTION EXPLAINED:
RSA is completely different from previous algorithms because:
- It uses TWO keys: public key (for encryption) and private key (for decryption)
- It's based on mathematical problems with large prime numbers
- It's much slower than symmetric algorithms like AES/DES
- It's used for secure key exchange and digital signatures

Main Steps:
1. Key Generation: Create public and private keys
2. Encryption: Use public key to encrypt
3. Decryption: Use private key to decrypt

Mathematical Foundation:
- Based on the difficulty of factoring large numbers
- Uses modular arithmetic and Euler's theorem
*/

// Simple function to check if a number is prime
int is_prime(uint64_t n) {
    /*
    PRIME CHECK:
    A prime number is only divisible by 1 and itself.
    We check divisibility by numbers up to sqrt(n).
    */
    if (n < 2) return 0;
    if (n == 2) return 1;
    if (n % 2 == 0) return 0;

    for (uint64_t i = 3; i * i <= n; i += 2) {
        if (n % i == 0) return 0;
    }
    return 1;
}

// Find greatest common divisor (GCD)
uint64_t gcd(uint64_t a, uint64_t b) {
    /*
    GREATEST COMMON DIVISOR:
    The largest number that divides both a and b.
    Used to find numbers that are coprime (GCD = 1).
    */
    while (b != 0) {
        uint64_t temp = b;
        b = a % b;
        a = temp;
    }
    return a;
}

// Extended Euclidean Algorithm to find modular inverse
uint64_t mod_inverse(uint64_t e, uint64_t phi) {
    /*
    MODULAR INVERSE:
    Find a number d such that: (d * e) % phi = 1
    This is the mathematical foundation for the private key.
    */
    int64_t t1 = 0, t2 = 1;
    uint64_t r1 = phi, r2 = e;

    while (r2 > 0) {
        uint64_t q = r1 / r2;

        uint64_t temp_r = r2;
        r2 = r1 - q * r2;
        r1 = temp_r;

        int64_t temp_t = t2;
        t2 = t1 - q * t2;
        t1 = temp_t;
    }

    if (r1 == 1) {
        if (t1 < 0) return t1 + phi;
        return t1;
    }

    return 0; // No inverse exists
}

// Modular exponentiation: (base^exp) % mod
uint64_t mod_pow(uint64_t base, uint64_t exp, uint64_t mod) {
    /*
    MODULAR EXPONENTIATION:
    Efficiently compute large powers modulo a number.
    This is used for both encryption and decryption.

    Instead of computing base^exp directly (which would be huge),
    we use mathematical properties to compute it step by step.
    */
    uint64_t result = 1;
    base = base % mod;

    while (exp > 0) {
        // If exp is odd, multiply base with result
        if (exp % 2 == 1) {
            result = (result * base) % mod;
        }

        // exp must be even now
        exp = exp >> 1; // Divide exp by 2
        base = (base * base) % mod;
    }

    return result;
}

// Generate RSA keys
void generate_rsa_keys(uint64_t* n, uint64_t* e, uint64_t* d) {
    /*
    RSA KEY GENERATION:
    1. Choose two distinct prime numbers p and q
    2. Compute n = p * q (the modulus)
    3. Compute φ(n) = (p-1) * (q-1) (Euler's totient function)
    4. Choose e such that: 1 < e < φ(n) and gcd(e, φ(n)) = 1
    5. Compute d such that: (d * e) % φ(n) = 1

    Public Key: (n, e)
    Private Key: (n, d)
    */

    // Step 1: Choose two prime numbers
    uint64_t p = 61;  // First prime
    uint64_t q = 53;  // Second prime

    printf("Key Generation:\n");
    printf("  p = %lu (first prime)\n", p);
    printf("  q = %lu (second prime)\n", q);

    // Step 2: Compute modulus n
    *n = p * q;
    printf("  n = p * q = %lu (modulus)\n", *n);

    // Step 3: Compute Euler's totient φ(n)
    uint64_t phi = (p - 1) * (q - 1);
    printf("  φ(n) = (p-1)*(q-1) = %lu\n", phi);

    // Step 4: Choose public exponent e
    *e = 17;  // Common choice: 65537 or 17
    while (gcd(*e, phi) != 1) {
        (*e)++;
    }
    printf("  e = %lu (public exponent)\n", *e);

    // Step 5: Compute private exponent d
    *d = mod_inverse(*e, phi);
    printf("  d = %lu (private exponent)\n", *d);

    printf("\nPublic Key: (n=%lu, e=%lu)\n", *n, *e);
    printf("Private Key: (n=%lu, d=%lu)\n", *n, *d);
}

// RSA Encryption
uint64_t rsa_encrypt(uint64_t message, uint64_t n, uint64_t e) {
    /*
    RSA ENCRYPTION:
    ciphertext = (message^e) % n

    Uses the public key (n, e) to encrypt.
    The message must be less than n.
    */
    printf("Encrypting: %lu^%lu mod %lu\n", message, e, n);
    return mod_pow(message, e, n);
}

// RSA Decryption
uint64_t rsa_decrypt(uint64_t ciphertext, uint64_t n, uint64_t d) {
    /*
    RSA DECRYPTION:
    message = (ciphertext^d) % n

    Uses the private key (n, d) to decrypt.
    This recovers the original message.
    */
    printf("Decrypting: %lu^%lu mod %lu\n", ciphertext, d, n);
    return mod_pow(ciphertext, d, n);
}

// Convert string to number (simple representation)
uint64_t string_to_number(const char* str) {
    /*
    STRING TO NUMBER:
    Convert a short string to a numerical representation.
    In real RSA, we'd use proper padding and convert bytes.
    */
    uint64_t result = 0;
    for (int i = 0; str[i] != '\0'; i++) {
        result = result * 256 + (uint8_t)str[i];
    }
    return result;
}

// Convert number back to string (for short numbers)
void number_to_string(uint64_t num, char* str, int max_len) {
    /*
    NUMBER TO STRING:
    Convert numerical representation back to string.
    This only works for our simple demonstration.
    */
    int pos = max_len - 1;
    str[pos] = '\0';

    while (pos > 0 && num > 0) {
        str[--pos] = num % 256;
        num /= 256;
    }
}

// Helper function to print hex data
void print_hex(const char* label, const uint8_t* data, int len) {
    printf("%s: ", label);
    for (int i = 0; i < len; i++) {
        printf("%02X", data[i]);
    }
    printf("\n");
}

int main() {
    printf("=== Simple RSA Encryption Demo ===\n\n");

    uint64_t n, e, d;  // RSA parameters

    // Step 1: Generate RSA keys
    generate_rsa_keys(&n, &e, &d);
    printf("\n");

    // Example message (must be less than n)
    char message[] = "HI";  // Short message to fit in our small n
    uint64_t message_num = string_to_number(message);

    printf("Message: '%s'\n", message);
    printf("Message as number: %lu\n", message_num);
    printf("\n");

    // Check if message is too large
    if (message_num >= n) {
        printf("Error: Message too large for current key size.\n");
        printf("Message must be less than n=%lu\n", n);
        return 1;
    }

    // Step 2: Encryption
    printf("ENCRYPTION PROCESS:\n");
    uint64_t ciphertext = rsa_encrypt(message_num, n, e);
    printf("Ciphertext: %lu\n", ciphertext);
    printf("\n");

    // Step 3: Decryption
    printf("DECRYPTION PROCESS:\n");
    uint64_t decrypted_num = rsa_decrypt(ciphertext, n, d);
    printf("Decrypted number: %lu\n", decrypted_num);

    // Convert back to string
    char decrypted_text[10];
    number_to_string(decrypted_num, decrypted_text, sizeof(decrypted_text));
    printf("Decrypted text: '%s'\n", decrypted_text);
    printf("\n");

    // Verification
    if (message_num == decrypted_num) {
        printf("✓ RSA Encryption/Decryption successful!\n");
    }
    else {
        printf("✗ RSA Encryption/Decryption failed!\n");
    }

    printf("\n=== Additional Example: Number Encryption ===\n\n");

    // Example with a simple number
    uint64_t simple_message = 42;
    printf("Simple message: %lu\n", simple_message);

    uint64_t simple_cipher = rsa_encrypt(simple_message, n, e);
    printf("Encrypted: %lu\n", simple_cipher);

    uint64_t simple_decrypted = rsa_decrypt(simple_cipher, n, d);
    printf("Decrypted: %lu\n", simple_decrypted);

    if (simple_message == simple_decrypted) {
        printf("✓ Number encryption successful!\n");
    }

    return 0;
}